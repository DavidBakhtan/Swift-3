import Cocoa

// Base Class: Computer
class Computer {
    var brand: String
    var processor: String
    var ram: Int
    
    init(brand: String, processor: String, ram: Int) {
        self.brand = brand
        self.processor = processor
        self.ram = ram
    }
    
    func displaySpecs() {
        print("Brand: \(brand), Processor: \(processor), Ram: \(ram)")
    }
}



// Subclass: Laptop
class Laptop: Computer {
    var isTouchscreen: Bool
    
    init(brand: String, processor: String, ram: Int, isTouchscreen: Bool) {
        self.isTouchscreen = isTouchscreen
        super.init(brand: brand, processor: processor, ram: ram)
    }
    
    override func displaySpecs() {
        super.displaySpecs()
        print("Touchscreen: \(isTouchscreen ? "Yes" : "No")")
    }
}


// Subclass: Desktop
class Desktop: Computer {
    var hasDedicatedGPU: Bool
    
    init(brand: String, processor: String, ram: Int, hasDedicatedGPU: Bool) {
        self.hasDedicatedGPU = hasDedicatedGPU
        super.init(brand: brand, processor: processor, ram: ram)
    }
    
    override func displaySpecs() {
        super.displaySpecs()
        print("Dedicated GPU: \(hasDedicatedGPU ? "Yes" : "No")")
    }
}

// Subclass: Server
class Server: Computer {
    var rackUnits: Int
    
    init(brand: String, processor: String, ram: Int, rackUnits: Int) {
        self.rackUnits = rackUnits
        super.init(brand: brand, processor: processor, ram: ram)
    }
    
    override func displaySpecs() {
        super.displaySpecs()
        print("Rack Units: \(rackUnits)")
    }
}


// Test Code
let myLaptop = Laptop(brand: "Microsoft", processor: "Intel i5", ram: 16, isTouchscreen: false)
let myDesktop = Desktop(brand: "Acer", processor: "Intel i9 ", ram: 32, hasDedicatedGPU: true)
let myServer = Server(brand: "Asus", processor: "Xeon", ram: 64, rackUnits: 4)

print("Laptop Specs:")
myLaptop.displaySpecs()

print("\nDesktop Specs:")
myDesktop.displaySpecs()

print("\nServer Specs:")
myServer.displaySpecs()
